<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}
require 'function.php';
if(isset($_POST["tombol"])){
    if (tambah1($_POST)>0){
        echo "<script>
        alert ('Data Berhasil Disimpan');
        document.location.href='index.php';
        </script>";
    } else{
        echo "<script>
        alert ('Data Gagal Disimpan');
        document.location.href='index.php';
        </script>";
    }

    
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <div id="logo-atas">
<img src="logo.png" alt="Logo Sekolah">
    </div>
    <div id="header-title">
<a href="index.php">hotel</a>
    </div>
    </div>
    <div class="menu">
        <ul class="menu-item">
        <li class="menu-item"><a href="index.php">Beranda</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Data</a></li>
        <li class="menu-item"><a href="tentang.php">Tentang Kami</a></li>
        <li class="menu-item"><a href="login.php">Hapus</a></li>
        </ul>
    </div>
    <div class="konten">
    <h2>Tambah Nama </h2>
    <form action="" method="POST">
<ul>
<li><label for="">Nama</label></li>
<li><input type="text" name="nama"></li>
<li><label for="">Jenis kelamin</label></li>
<li>
    <select name="jenis_kelamin" required>
        <option>laki-laki</option>
        <option>perempuan</option>
</select>
</li>
    <li><label for="">Kelas</label></li>
    <li><input type="text" name="kelas"></li>
    <li><label for="">Umur</label></li>
    <li><input type="text" name="umur"></li>
    <li><label for="">No HP</label></li>
    <li><input type="text" name="no_hp"></li>
    <li><label for="">Tanggal Lahir</label></li>
    <li><input type="text" name="tanggal_lahir"></li>
    <li><label for="">Pengalaman</label></li>
    <li><input type="text" name="pengalaman"></li>
    <li><label for="">Hobi</label></li>
    <li><textarea name="hobi" id=""></textarea>
    <li><label for="">Alamat</label></li>
    <li><input type="text" name="alamat"></li>
    <li><label for="">Skill</label></li>
    <li><input type="text" name="skill"></li>
    <li><label for="">Pendidikan</label></li>
    <li><textarea type="text" name="pendidikan"></textarea></li>
    <li><label for="">Pekerjaan</label></li>
    <li><textarea name="pekerjaan" id=""></textarea></li>
    <li><button type="submit" name="tombol">Simpan data</button></li>
</ul>
    </form>
    </div>
</body>
</html>