<?php
require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM sri");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV EDITH BAHARI SYA'BANI</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div class="header">
    <div class="gambar"> <img src="hanao.jpg" alt="ini gambar sri">
    </div>
    <?php
    foreach ($cari as $cari2):
    ?>
    <h1><?= $cari2 ['nama'];?></h1>
    <h3><?php echo $cari2['hobi'];?></h3>
    <?php
    endforeach;
    ?>
    </div>
    <div class="main">
    <div class="left">
        <h2>Informasi Identitas</h2>
        <p><strong>NAMA :</strong> wahid</p>
        <p><strong>ALAMAT : </strong> <?php echo $cari2['alamat'];?></p>
        <p><strong>NO.TELEPON : </strong><?php echo $cari2 ['no_hp'];?></p>
        <p><strong>SKILL : </strong> <?php echo $cari2['skill'];?></p>
        <h2>Pendidikan</h2>
        <p><strong></strong><?php echo $cari2['pendidikan'];?></p>
    </div>
    <div class="right">
        <h2>Pekerjaan</h2>
        </strong><?php echo $cari2['pekerjaan'];?></p>
        <h2>Pengalaman</h2>
        </strong><?php echo $cari2['pengalaman'];?></p>
    </div>
    </div>
    </div>
</body>
</html>